const mongoose =require('mongoose');
const downloadlogSchema = new mongoose.Schema({
    totalcount:{
        type:Number
    },
    searchquery:{
        type:String
    },
    downloadedby:{
        type:String
    },
    downloadedat:{
        type:Number
    }

})
module.exports =mongoose.model('downloadlog',downloadlogSchema);