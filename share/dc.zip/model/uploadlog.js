const mongoose =require('mongoose');
const uploadlogSchema = new mongoose.Schema({
    totalcount:{
        type:Number
    },
    successcount:{
        type:Number
    },
    failurecount:{
        type:Number
    },
    uploadedby:{
        type:String
    },
    uploadedat:{
        type:Number
    }

})
module.exports =mongoose.model('uploadlog',uploadlogSchema);