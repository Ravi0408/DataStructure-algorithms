const mongoose =require('mongoose');
const metadataSchema = new mongoose.Schema({
    name:{
        type:String,
        unique:true
    },
    companyname:[{type:String}],
    jobtitle:[{type:String}],
    jobfunction:[{type:String}],
    emailstatus:{
        type:String,
        enum:['Valid','Invalid'],
        default:'Valid'
    },
    city:[{type:String}],
    state:[{type:String}],
    zipcode:[{type:String}],
    joblevel:[{type:String}],
    country:[{
        type:String,
        unique:true
    }],
    industry:[{type:String}],
    industrytype:[{type:String}],
    employeesizemax:Number,
    qcstatus:{
        type:String,
        enum:['Disqualified','Qualified','QC Clear'],
        default:'Qualified'
    },

})
module.exports =mongoose.model('metadata',metadataSchema);