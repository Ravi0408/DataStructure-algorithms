function checkSignIn(req,res,next){
    if(req.session.user){
        next();
    }else{
        res.redirect('/login');
       
    }
}
function checkSignOut(req,res,next){
    if(req.session.user){
        res.redirect('/');
                
    }else{
        next();
    }
}
function isManager(req,res,next){
    if(req.session.user.Role==="Admin" || req.session.user.Role==="Manager"){
        next();
    }
    else{
        res.redirect('/');
        
    }
}

function isadmin(req,res,next){
    if(req.session.user.Role==="Admin"){
        next();
    }
    else{
        res.redirect('/');
        
    }
}
module.exports={
    checkSignIn,
    checkSignOut,
    isadmin,
    isManager
}