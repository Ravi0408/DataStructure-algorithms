const router=       require('express').Router();
const fs=           require('fs');
const uploadlog=require('../model/uploadlog')
const downloadlog=require('../model/downloadlog')
const {
    checkSignIn,
    checkSignOut,
    isManager,
    isadmin}=           require('./auths');
router.get('/uploadlogs',checkSignIn,(req,res)=>{
    uploadlog.find({},(err,result)=>{
        if(err) return res.send(err);
        res.render('uploadlogs.ejs',{user:req.session.user,data:result})
    })
})
router.get('/downloadlogs',checkSignIn,(req,res)=>{
    downloadlog.find({},(err,result)=>{
        if(err) return res.send(err);
        res.render('downloadlogs.ejs',{user:req.session.user,data:result})
    })
})


module.exports=router;