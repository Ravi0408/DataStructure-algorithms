const router=       require('express').Router();
const User=         require('../model/user');
const fs=           require('fs');
const bcrypt=       require('bcryptjs');
const data=         require('../model/data');
const {checkSignIn,checkSignOut,isManager,isadmin}=           require('./auths');
const downloadlog = require('../model/downloadlog');
const uploadlog = require('../model/uploadlog');
router.get('/',checkSignIn,(req,res)=>{
    data.aggregate([
        {
            $match: {}
        },
        {
            $count: "totalcount"
        }
    ],
(err,result)=>{
    if(err) return res.send(err)
    d=new Date();
    datenumber= Date.UTC(d.getFullYear(),d.getMonth(),d.getDate());
    console.log(datenumber);
    uploadlog.aggregate([
        {
            $match: {uploadedat:{$gte:datenumber}}
        },
        {
            $group:{_id:null,totaluploadeddata:{$sum:"$successcount"}}
        }
    ],(err,uploaddata)=>{
        console.log(uploaddata)
        downloadlog.aggregate([
            {
                $match: {downloadedat:{$gte:datenumber}}
            },
            {
                $group:{_id:null,totaldownlodeddata:{$sum:"$totalcount"}}
            }
            // {
            //     $count: "totalcount"
            // }
        ],(err,downloaddata)=>{
            
            res.render('index.ejs',{user:req.session.user,
                resultcount:result[0]?.totalcount,
                totaluploaded:uploaddata[0]?.totaluploadeddata,
                totaldownloaded:downloaddata[0]?.totaldownlodeddata
            });
        })  
    })
})
});
router.get('/login',checkSignOut,(req,res)=>{
    res.render('login.ejs')
})

router.get('/createuser',checkSignIn,(req,res)=>{
    res.render('createuser.ejs',{user:req.session.user})
})

router.post('/adduser',checkSignIn, async(req,res)=>{
    console.log(req.body);
   
    const userExist = await User.findOne({employeeID: req.body.EmployeeID});
    
    if(userExist) return res.status(400).send('user already exists');
    const saltRounds=10;
    const hash = bcrypt.hashSync(req.body.Password, saltRounds);

    const user = new User({
        username:req.body.Name,
        employeeID:req.body.EmployeeID,
        email:req.body.Email,
        role:req.body.Role,
        department:req.body.Department,
        password:hash
    });
    try{
        const savedUser= await user.save();
        // res.send(savedUser);
        // req.session.user=savedUser;
        console.log("employee added");
        res.redirect('/createuser')

    }catch(err){
        console.log(err);
        res.status(400).send("Error occured");
    }
  
})

router.get('/userlist',checkSignIn, (req,res)=>{
    User.find(function(err,data){
        if(err){
            console.log(err);
        }
        else{
            // res.send(data);
            // console.log(data);
            
            res.render('userlist.ejs',{records:data,user:req.session.user})
        }
    })
})
router.post('/login',async (req,res)=>{
// console.log(user);


if(!req.body.EmployeeID || !req.body.Password){
    res.render('login.ejs',{message:"Please enter credentials"})
}else{
    const user = await User.findOne({employeeID: req.body.EmployeeID});
    if(!user)  return res.redirect('/login');
    if(user.status=="Inactive") return res.render('login.ejs',{message:"User Disabled"})
    if(user.employeeID=== req.body.EmployeeID && bcrypt.compareSync(req.body.Password, user.password)){
        req.session.user =user;
        console.log(`stored ${user} in session`)
        res.redirect('/');
    }else{
        console.log(`else part`)
        res.render("login.ejs",{message:"Wrong credentials"});
    }
}

})
router.get('/updateUser/:EmployeeID',checkSignIn, async(req,res)=>{
    console.log(req.params)
    const user = await User.findOne({employeeID: req.params.EmployeeID});
    if(!user)  return res.redirect('/createuser')
    //console.log(user);
    data=[user];
    console.log(data);
    res.render('updateuser.ejs',{data:data,user:req.session.user});
})
// router.get('/easteregg0408',(req,res)=>{
//     res.download('./data/login.log');
// })
router.post('/updateUser/:EmployeeID',checkSignIn, async (req,res)=>{
    const user = await User.findOne({employeeID: req.params.EmployeeID});
    console.log(typeof req.body.Password)
    if(typeof(req.body.Password)==='undefined' || req.body.Password==""){
        User.findOneAndUpdate({_id: user._id},
            {
                username:req.body.Name,
                employeeID:req.body.EmployeeID,
                email:req.body.Email,
                role:req.body.Role,
                department:req.body.Department,
        
            },
            function(err, data) {
                if(err){
                    console.log(err);
                }
                else{
                    res.redirect('/userlist');
                }
            }); 
        }else{
            console.log('update password')
            const saltRounds=10;
            const hash = bcrypt.hashSync(req.body.Password, saltRounds);

            User.findOneAndUpdate({_id: user._id},
                {
                    userame:req.body.Name,
                    employeeID:req.body.EmployeeID,
                    email:req.body.Email,
                    role:req.body.Role,
                    department:req.body.Department,
                    password:hash
                },
                function(err, data) {
                    if(err){
                        console.log(err);
                    }
                    else{
                        res.redirect('/userlist');
                    }
                }); 
        
    }
})

router.get('/updateStatus/:EmployeeID',async(req,res)=>{
    try {
        const user = await User.findOne({employeeID: req.params.EmployeeID});
        let newstatus='';
        if(user.status=="Active"){
            newstatus="Inactive";
        }else{
            newstatus="Active";
        }
        User.findOneAndUpdate({_id: user._id},
            {
                status:newstatus
            },
            function(err, data) {
                if(err){
                    console.log(err);
                }
                else{
                    res.redirect('/userlist');
                }
            }); 
    } catch (err) {
        console.error(err)
        res.render('error.ejs',{user:req.session.user})
    }
})

router.get('/delete/:EmployeeID',checkSignIn,isadmin, async(req,res)=>{
    User.deleteOne({EmployeeID:req.params.EmployeeID}, 
        function(err, data) {
            if(err){
                console.log(err);
            }
            else{
                res.redirect('/userlist');
                // res.send(data);
                // console.log("Data Deleted!");
            }
        });  
})


router.get("/logout",checkSignIn,(req,res)=>{
    req.session = null
    console.log("user logged out");
    res.redirect('/login')
});
module.exports=router;