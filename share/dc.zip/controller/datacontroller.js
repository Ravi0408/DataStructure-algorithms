const router=       require('express').Router();
const User=         require('../model/user');
const data=         require('../model/data');
const uploadlogger=         require('../model/uploadlog');
const downloadlogger=         require('../model/downloadlog');
const fs=           require('fs');
const bcrypt=       require('bcryptjs')
const csv=          require('csvtojson')
const { Parser } = require('json2csv');
const {
    checkSignIn,
    checkSignOut,
    isManager,
    isadmin}=           require('./auths');
const async = require('async');
const metadata = require('../model/metadata');
const bodyParser = require("body-parser");
const user = require('../model/user');
var urlencodedparser = bodyParser.urlencoded({extended:false})

router.get('/error',checkSignIn,(req,res)=>{
    res.render('error.ejs',{user:req.session.user})
})

router.get('/csvupload',checkSignIn,(req,res)=>{
    res.render('uploaddata.ejs',{user:req.session.user})
})
router.get('/reupload',checkSignIn,(req,res)=>{
    res.render('reupload.ejs',{user:req.session.user})
})
router.get('/downloaddata',checkSignIn,(req,res)=>{
    //get metadata
    metadata.find({name:"metadata"},(err,result)=>{
        if(err) throw err;
        // console.log(result)
        res.render('downloaddata.ejs',{user:req.session.user,data:result[0]})
    })
})

// router.get('/getindustrytype',(req,res)=>{
//     data.aggregate([{
//             $group:{
//                 _id:"",
//                 industrytype:{ $addToSet:"$industrytype"}
//             }
//         },
//         // {
//         //     $unwind:"$industrytype"
//         // },
//         // {
//         //     $project:{
//         //         _id:0
//         //     }
//         // }
//     ],
//     (err,result)=>{
//         if(err) return res.send(err)
//         res.send(result);
//     })
// })

router.get('/getmeta',checkSignIn,(req,res)=>{
    data.aggregate([{
            $group:{
                _id:"",
                industry:{ $addToSet:"$industry"},
                tags:{ $addToSet:"$tags"},
                leadtype:{$addToSet:"$leadtype"},
                joblevel:{$addToSet:"$joblevel"},
            }
        },
        // {
        //     $unwind:"$industrytype"
        // },
        // {
        //     $project:{
        //         _id:0
        //     }
        // }
    ],
    (err,result)=>{
        if(err) return res.send(err)
        res.send(result);
    })
})

// router.get('/gettags',(req,res)=>{
//     data.aggregate([{
//             $group:{
//                 _id:"",
//                 tags:{ $addToSet:"$tags"}
//             }
//         },
//         // {
//         //     $unwind:"$industrytype"
//         // },
//         // {
//         //     $project:{
//         //         _id:0
//         //     }
//         // }
//     ],
//     (err,result)=>{
//         if(err) return res.send(err)
//         res.send(result);
//     })
// })

router.get('/getjobtitle/:level',checkSignIn,(req,res)=>{
    console.log(req.params)
    data.aggregate([
        {"$match":{"joblevel":req.params.level}},
    {
       $project:{
        jobtitle:"$jobtitle",
        city:"$city",
        country:"$country",
        industry:"$industry",
        industrytype:"$industrytype"
       }
    },
    // {
    //     $count:"sum"
    // }
],
    (err,result)=>{
        if(err) return res.send(err)
        res.send(result);
    })
})

router.get('/getindustrytype/:industries',checkSignIn,(req,res)=>{
    console.log(req.params)
    data.aggregate([{"$match":{"industry":req.params.industries}},
    {
       $project:{
        industrytype:"$industrytype"
       }
    },
    // {
    //     $count:"sum"
    // }
],
    (err,result)=>{
        if(err) return res.send(err)
        res.send(result);
    })
})

router.get('/jobfunctioncount',checkSignIn,(req,res)=>{
    data.aggregate([
       {
         "$group":{_id:"$jobfunction",count:{$sum:1}}
}],
(err,result)=>{
    if(err) return res.send(err)
    res.send(result)
})
});
router.get('/qualitytagscount',checkSignIn,(req,res)=>{
    data.aggregate([
       {
         "$group":{_id:"$tags",count:{$sum:1}}
}],
(err,result)=>{
    if(err) return res.send(err)
    res.send(result)
})
});




router.post('/downloaddata',checkSignIn,(req,res)=>{
    console.log(req.body)

    let obj=formatquery(req.body);
    try {
        data.find({$and:[
            obj
        ]},(err,result)=>{
            if(err) throw err;
            console.log(result.length);
            // console.log(result);
            // res.send(`${result.length}`)
            var downloadlog = new downloadlogger({
                totalcount:result.length,
                searchquery:JSON.stringify(obj),
                downloadedby:req.session.user.username,
                downloadedat:Date.now()
            })
            downloadlog.save();
    
            let csv;
            const filePath = "./files/result.csv";
            const fields = require('../model/fields');
            try {
                const json2csvParser = new Parser({ fields });
                 csv = json2csvParser.parse(result);
                 
                 
            } catch (err) {
                return res.status(500).json({err});
            }
        
        fs.writeFile(filePath, csv, function (err) {
                if (err) {
                    return res.json(err).status(500);
                }
                else {
                    setTimeout(function () {
                        fs.unlink(filePath, function (err) { // delete this file after 30 seconds
                        if (err) {
                            console.error(err);
                        }
                        console.log('File has been Deleted');
                    });
        
                }, 30000);
                    res.download(filePath);
                }
            })
            // res.render('displaydata.ejs',{user:req.session.user,record:result})
            // res.json(result)
            // res.send(result)
        })
    } catch (err) {
        console.error(err)
        res.render('error.ejs',{user:req.session.user})
    }
    
    
})
router.post('/reupload',checkSignIn,(req,res)=>{
    if(req.files?.file==null){ //this should be handled on frontend
        return res.redirect('/reupload')
    }

    const file = req.files.file;
    const path = "./files/" + file.name;
    try {
        file.mv(path, (err) => {
            if (err) {
                return res.status(500).send(err);
            }
            csv()
            .fromFile(path)
            .then((jsonObj)=>{
                console.log(jsonObj.length);
                var successcount=0;
                var failurecount=0;
                var totalresult={
                    content:[],
                    duplicate:[],
                    failed:[],
                    uploadedby:req.session.user.username,
                    successcount:successcount,
                    failurecount:failurecount,
                    link:''
                }
                async.eachOfSeries(jsonObj,
                    function(dataVar, key, callback) {
                    data.findOneAndUpdate({
                        firstname: dataVar.firstname,
                        lastname: dataVar.lastname,
                        phonenumber:dataVar.phonenumber,
                        email:dataVar.email,
                        companyname:dataVar.companyname
                    },
                    modifydatavar(dataVar)
                    , function(err, result) {
                        if (err) { // Insert If data not exist
                            failurecount++;
                            dataVar.reason=`Error in ${err.path}`
                            totalresult.failed.push(dataVar);
                            Name=`${dataVar.firstname} ${dataVar.lastname}`;
                            totalresult.content.push({Name:Name, status: "failed" })
                            console.log(err.errors)
                            callback();
                        } else { // Update records if user exist
                           successcount++;
                            Name=`${dataVar.firstname} ${dataVar.lastname}`;
                            totalresult.content.push({Name:Name, status: "ok" })
                          
                            // Name=`${dataVar.firstname} ${dataVar.lastname}`;
                            // totalresult.duplicate.push(dataVar);
                            // totalresult.content.push({Name:Name ,status:"duplicate data"});
                            // failurecount++
                            callback();
                           
                        }
                    })
                }, 
                function(err) {
                    if (err) console.error(err.message);
                    console.log(`successcount:${successcount}`)
                    console.log(`failurecount:${failurecount}`)
                    totalresult.failurecount=failurecount;
                    totalresult.successcount=successcount;
                    var toupload = new uploadlogger({
                        totalcount:jsonObj.length,
                        successcount:successcount,
                        failurecount:failurecount,
                        uploadedby:req.session.user.username,
                        uploadedat:Date.now()
                    })
                    toupload.save();
                    // uploadlog(JSON.stringify(totalresult))
        
                    let csv;
                    const filePath = "./files/duplicate.csv";
                    totalresult.link=filePath;
                    const fields = require('../model/fields');
                    
                    try {
                        const json2csvParser = new Parser({ fields });
                         csv = json2csvParser.parse(totalresult.failed);
                    } catch (err) {
                        return res.status(500).json({err});
                    }
                
                    fs.writeFile(filePath, csv, function (err) {
                        if (err) {
                            return res.json(err).status(500);
                        }
                        else {
                            setTimeout(function () {
                                fs.unlink(filePath, function (err) { // delete this file after 30 seconds
                                if (err) {
                                    console.error(err);
                                }
                                console.log('File has been Deleted');
                            });
                
                        }, 30000);
                            // res.download(filePath);
                        }
                    })
                    // res.render('displaydata.ejs',{user:req.session.user,record:result})
                    // res.json(result)
                    // res.send(result)
                    setTimeout(() => {fs.unlink(path,(err)=>{
                        if(err) console.log(err)
                        console.log('file deleted')
                    })}, 150000);
                    console.log("All done")
                    res.render("resultlog.ejs",{user:req.session.user,result:totalresult})
                })
                });
                
             
            })
    } catch (err) {
        console.error(err)
        res.render('error.ejs',{user:req.session.user})
    }
    
   
})
router.post('/getdatacount',checkSignIn,async(req,res)=>{
    try {
        abmfile=req.files?.abmfile
        suppressionfile=req.files?.suppressionfile
        let obj=formatquery(req.body);
        if(Object.keys(obj).length === 0){
            return res.json({count:'please select filters'})
        }

        if(req.files?.abmfile==null && req.files?.suppressionfile==null ){   
            // no file exist
            console.log('no files')
            let obj=formatquery(req.body);
            let query={$and:[obj]};
            let result= await data.find(query).lean();
            console.log({count:result.length})
            return res.json({count:result.length})

        }else if(req.files?.suppressionfile==null){
            console.log('Abm file')
            const abmpath = "./files/" + abmfile.name;
            abmfile.mv(abmpath,(err)=>{
                if(err){
                    return res.status(500).send(err)
                }
                csv()
                .fromFile(abmpath)
                .then(async(jsonObj)=>{
                    if(jsonObj.length==0){
                        return res.send("file is empty");
                    }
                    abmobj=processabm(jsonObj);
                    let obj=formatquery(req.body);
                    let query={$and:[{$or:[obj]},{$or:[abmobj]}]};
                    let result= await data.find(query).lean();
                    console.log({count:result.length})
                    setTimeout(() => {fs.unlink(abmpath,(err)=>{
                        if(err) console.log(err)
                        console.log('abm file deleted')
                    })}, 150000);
                    return res.json({count:result.length})
                })
            })
            // abm exist and suppression dosent
        }else if(req.files?.abmfile==null){
            console.log('suppression file')
            const suppressionpath = "./files/" + suppressionfile.name;
            suppressionfile.mv(suppressionpath,(err)=>{
                if(err){
                    return res.status(500).send(err)
                }
                csv()
                .fromFile(suppressionpath)
                .then(async(jsonObj)=>{
                    if(jsonObj.length==0){
                        return res.send("file is empty");
                    }
                    sobj=processsuppressionquery(jsonObj);
                    let obj=formatquery(req.body);
                    let query={$and:[{$or:[obj]},sobj]};
                    console.log(query)
                    let result= await data.find(query).lean();
                    console.log({count:result.length})
                    setTimeout(() => {fs.unlink(suppressionpath,(err)=>{
                        if(err) console.log(err)
                        console.log('suppression file deleted')
                    })}, 150000);
                    return res.json({count:result.length})
                })
            })
            // abm dosent exist and suppression exist
        }else{
            console.log('both files')
            const abmpath = "./files/" + abmfile.name;
            abmfile.mv(abmpath,(err)=>{
                if(err){
                    return res.status(500).send(err)
                }
                csv()
                .fromFile(abmpath)
                .then(async(abmjsonObj)=>{
                    if(abmjsonObj.length==0){
                        return res.send("abm file is empty");
                    }
                    const suppressionpath = "./files/" + suppressionfile.name;
                    suppressionfile.mv(suppressionpath,(err)=>{
                        if(err){
                            return res.status(500).send(err)
                        }
                        csv()
                        .fromFile(suppressionpath)
                        .then(async(jsonObj)=>{
                            if(jsonObj.length==0){
                                return res.send("suppression file is empty");
                            }
                            abmobj=processabm(abmjsonObj);
                            suppressionobj=processabm(jsonObj);
                            let obj=formatquery(req.body);
                            let query={$and:[{$or:[obj]},{$or:[abmobj]}]};
                            console.log(query)
                            let result= await data.find(query).lean();
                            console.log({count:result.length})
                            setTimeout(() => {fs.unlink(suppressionpath,(err)=>{
                                if(err) console.log(err)
                                console.log('suppression file deleted')
                            })}, 150000);
                            setTimeout(() => {fs.unlink(abmpath,(err)=>{
                                if(err) console.log(err)
                                console.log('abm file deleted')
                            })}, 150000);
                            return res.json({count:result.length})
                        })
                    })
                    abmobj=processabm(jsonObj);
                    let obj=formatquery(req.body);
                    let query={$and:[{$or:[obj]},{$or:[abmobj]}]};
                    let result= await data.find(query).lean();
                    console.log({count:result.length})
                    
                    
                    return res.json({count:result.length})
                })
            })
            //both file exist
        }
    } catch (err) {
        console.error(err)
        res.render('error.ejs',{user:req.session.user})
    }
})
router.post('/datafiledownload',checkSignIn,async(req,res)=>{
    try {
        abmfile=req.files?.abmfile
        suppressionfile=req.files?.suppressionfile
        let obj=formatquery(req.body);
        if(Object.keys(obj).length === 0){
            return res.json({count:'please select filters'})
        }
        const fields = require('../model/fields');

        if(req.files?.abmfile==null && req.files?.suppressionfile==null ){   
            // no file exist
            console.log('no files')
            let obj=formatquery(req.body);
            let query={$and:[obj]};
            let result= await data.find(query).lean();
            var downloadlog = new downloadlogger({
                totalcount:result.length,
                searchquery:JSON.stringify(obj),
                downloadedby:req.session.user.username,
                downloadedat:Date.now()
            })
            downloadlog.save();
            let csv;
            const filePath = "./files/result.csv";
            try {
                const json2csvParser = new Parser({ fields });
                 csv = json2csvParser.parse(result);
                 
                 
            } catch (err) {
                return res.status(500).json({err});
            }
            fs.writeFile(filePath, csv, function (err) {
                if (err) {
                    return res.json(err).status(500);
                }
                else {
                    setTimeout(function () {
                        fs.unlink(filePath, function (err) { // delete this file after 30 seconds
                        if (err) {
                            console.error(err);
                        }
                        console.log('File has been Deleted');
                    });
        
                }, 30000);
                    return res.download(filePath);
                }
            })
        }else if(req.files?.suppressionfile==null){
            console.log('Abm file')
            const abmpath = "./files/" + abmfile.name;
            abmfile.mv(abmpath,(err)=>{
                if(err){
                    return res.status(500).send(err)
                }
                csv()
                .fromFile(abmpath)
                .then(async(jsonObj)=>{
                    if(jsonObj.length==0){
                        return res.send("file is empty");
                    }
                    abmobj=processabm(jsonObj);
                    let obj=formatquery(req.body);
                    let query={$and:[{$or:[obj]},{$or:[abmobj]}]};
                    let result= await data.find(query).lean();
                    console.log({count:result.length})
                    var downloadlog = new downloadlogger({
                        totalcount:result.length,
                        searchquery:JSON.stringify(obj),
                        downloadedby:req.session.user.username,
                        downloadedat:Date.now()
                    })
                    downloadlog.save();
                    let csv;
                    const filePath = "./files/result.csv";
                    try {
                        const json2csvParser = new Parser({ fields });
                         csv = json2csvParser.parse(result);
                         
                         
                    } catch (err) {
                        return res.status(500).json({err});
                    }
                    fs.writeFile(filePath, csv, function (err) {
                        if (err) {
                            return res.json(err).status(500);
                        }
                        else {
                            setTimeout(function () {
                                fs.unlink(filePath, function (err) { // delete this file after 30 seconds
                                if (err) {
                                    console.error(err);
                                }
                                console.log('File has been Deleted');
                            });
                
                        }, 30000);
                            return res.download(filePath);
                        }
                    })
                    setTimeout(() => {fs.unlink(abmpath,(err)=>{
                        if(err) console.log(err)
                        console.log('abm file deleted')
                    })}, 150000);
                })
            })
            // abm exist and suppression dosent
        }else if(req.files?.abmfile==null){
            console.log('suppression file')
            const suppressionpath = "./files/" + suppressionfile.name;
            suppressionfile.mv(suppressionpath,(err)=>{
                if(err){
                    return res.status(500).send(err)
                }
                csv()
                .fromFile(suppressionpath)
                .then(async(jsonObj)=>{
                    if(jsonObj.length==0){
                        return res.send("file is empty");
                    }
                    sobj=processsuppressionquery(jsonObj);
                    let obj=formatquery(req.body);
                    let query={$and:[{$or:[obj]},sobj]};
                    console.log(query)
                    let result= await data.find(query).lean();
                    console.log({count:result.length})

                    var downloadlog = new downloadlogger({
                        totalcount:result.length,
                        searchquery:JSON.stringify(obj),
                        downloadedby:req.session.user.username,
                        downloadedat:Date.now()
                    })
                    downloadlog.save();
                    let csv;
                    const filePath = "./files/result.csv";
                    try {
                        const json2csvParser = new Parser({ fields });
                         csv = json2csvParser.parse(result);
                         
                         
                    } catch (err) {
                        return res.status(500).json({err});
                    }
                    fs.writeFile(filePath, csv, function (err) {
                        if (err) {
                            return res.json(err).status(500);
                        }
                        else {
                            setTimeout(function () {
                                fs.unlink(filePath, function (err) { // delete this file after 30 seconds
                                if (err) {
                                    console.error(err);
                                }
                                console.log('File has been Deleted');
                            });
                
                        }, 30000);
                            return res.download(filePath);
                        }
                    })
                    setTimeout(() => {fs.unlink(suppressionpath,(err)=>{
                        if(err) console.log(err)
                        console.log('suppression file deleted')
                    })}, 150000);
                })
            })
            // abm dosent exist and suppression exist
        }else{
            console.log('both files')
            const abmpath = "./files/" + abmfile.name;
            abmfile.mv(abmpath,(err)=>{
                if(err){
                    return res.status(500).send(err)
                }
                csv()
                .fromFile(abmpath)
                .then(async(abmjsonObj)=>{
                    if(abmjsonObj.length==0){
                        return res.send("abm file is empty");
                    }
                    const suppressionpath = "./files/" + suppressionfile.name;
                    suppressionfile.mv(suppressionpath,(err)=>{
                        if(err){
                            return res.status(500).send(err)
                        }
                        csv()
                        .fromFile(suppressionpath)
                        .then(async(jsonObj)=>{
                            if(jsonObj.length==0){
                                return res.send("suppression file is empty");
                            }
                            abmobj=processabm(abmjsonObj);
                            suppressionobj=processabm(jsonObj);
                            let obj=formatquery(req.body);
                            let query={$and:[{$or:[obj]},{$or:[abmobj]},suppressionobj]};
                            console.log(query)
                            let result= await data.find(query).lean();
                            console.log({count:result.length})
                            var downloadlog = new downloadlogger({
                                totalcount:result.length,
                                searchquery:JSON.stringify(obj),
                                downloadedby:req.session.user.username,
                                downloadedat:Date.now()
                            })
                            downloadlog.save();
                            let csv;
                            const filePath = "./files/result.csv";
                            try {
                                const json2csvParser = new Parser({ fields });
                                 csv = json2csvParser.parse(result);
                                 
                                 
                            } catch (err) {
                                return res.status(500).json({err});
                            }
                            fs.writeFile(filePath, csv, function (err) {
                                if (err) {
                                    return res.json(err).status(500);
                                }
                                else {
                                    setTimeout(function () {
                                        fs.unlink(filePath, function (err) { // delete this file after 30 seconds
                                        if (err) {
                                            console.error(err);
                                        }
                                        console.log('File has been Deleted');
                                    });
                        
                                }, 30000);
                                    return res.download(filePath);
                                }
                            })
                            setTimeout(() => {fs.unlink(suppressionpath,(err)=>{
                                if(err) console.log(err)
                                console.log('suppression file deleted')
                            })}, 150000);
                            setTimeout(() => {fs.unlink(abmpath,(err)=>{
                                if(err) console.log(err)
                                console.log('abm file deleted')
                            })}, 150000);
                        })
                    })
                    
                })
            })
            //both file exist
        }
    } catch (err) {
        console.error(err)
        res.render('error.ejs',{user:req.session.user})
    }
})
router.post('/csvupload',checkSignIn,(req,res)=>{
    // console.log(req.body);
    console.log(req.files);
    if(req.files?.file==null){ //this should be handled on frontend
        return res.redirect('/csvupload')
    }
    
    
    const file = req.files.file;
    const path = "./files/" + file.name;
    if(file.mimetype!=="text/csv"){
        return res.send("please upload csv file")
    }

    try {
        file.mv(path, (err) => {
            if (err) {
                return res.status(500).send(err);
            }
            csv()
            .fromFile(path)
            .then((jsonObj)=>{
                console.log(jsonObj.length);
                var successcount=0;
                var failurecount=0;
                var totalresult={
                    content:[],
                    duplicate:[],
                    failed:[],
                    uploadedby:req.session.user.username,
                    successcount:successcount,
                    failurecount:failurecount,
                    link:''
                }
                async.eachOfSeries(jsonObj, function(dataVar, key, callback) {
                    data.findOne({
                        firstname: dataVar.firstname,
                        lastname: dataVar.lastname,
                        phonenumber:dataVar.phonenumber,
                        email:dataVar.email,
                        companyname:dataVar.companyname
                    }, function(err, result) {
                        if (!result) { // Insert If data not exist
                            
                            // modifieddatavar=modifydatavar(dataVar);
                            // modifymetadata(modifieddatavar);
        
                            var dataSchema = new data(modifydatavar(dataVar));
                            dataSchema.save(function(err, result) {
                                if(err){
                                    // console.log(err);
                                    // console.error(Object.values(err.errors).map(val=>val.message))
                                    failurecount++
                                    dataVar.reason=err.errors?Object.values(err.errors).map(val=>val.message):"undefined"
                                    
                                        totalresult.duplicate.push(dataVar);
                                    callback();
                                }else{
                                    console.log('New Record Inserted');
                                    Name=`${dataVar.firstname} ${dataVar.lastname}`;
                                    totalresult.content.push({Name:Name, status: "ok" })
                                    successcount++
                                    callback();
                                    
                                } 
                            })
                        } else { // Update records if user exist
                            // console.log(result)
                            // console.log('duplicate data')
                            dataVar.reason='duplicate data';
                            // console.log(result)
                            Name=`${dataVar.firstname} ${dataVar.lastname}`;
                            totalresult.duplicate.push(dataVar);
                            totalresult.content.push({Name:Name ,status:"duplicate data"});
                            failurecount++
                            callback();
                        }
                    })
                }, function(err) {
                    if (err) console.error(err.message);
                    console.log(`successcount:${successcount}`)
                    console.log(`failurecount:${failurecount}`)
                    totalresult.failurecount=failurecount;
                    totalresult.successcount=successcount;
                    var toupload = new uploadlogger({
                        totalcount:jsonObj.length,
                        successcount:successcount,
                        failurecount:failurecount,
                        uploadedby:req.session.user.username,
                        uploadedat:Date.now()
                    })
                    toupload.save();
                    // uploadlog(JSON.stringify(totalresult))
        
                    let csv;
                    const filePath = "./files/duplicate.csv";
                    totalresult.link=filePath;
                    const fields = require('../model/fields');
                   
                    try {
                        const json2csvParser = new Parser({ fields });
                         csv = json2csvParser.parse(totalresult.duplicate);
                         
                         
                    } catch (err) {
                        return res.status(500).json({err});
                    }
                
                    fs.writeFile(filePath, csv, function (err) {
                        if (err) {
                            return res.json(err).status(500);
                        }
                        else {
                            setTimeout(function () {
                                fs.unlink(filePath, function (err) { // delete this file after 30 seconds
                                if (err) {
                                    console.error(err);
                                }
                                console.log('File has been Deleted');
                            });
                
                        }, 30000);
                            // res.download(filePath);
                        }
                    })
                    // res.render('displaydata.ejs',{user:req.session.user,record:result})
                    // res.json(result)
                    // res.send(result)
                    setTimeout(() => {fs.unlink(path,(err)=>{
                        if(err) console.log(err)
                        console.log('file deleted')
                    })}, 150000);
                    console.log("All done")
                    res.render("resultlog.ejs",{user:req.session.user,result:totalresult})
                })
                });
                
             
            })
    } catch (err) {
        console.error(err)
        res.render('error.ejs',{user:req.session.user})
    }

    
   
});
    // res.render('uploaddata.ejs')

router.get('/downloaddupresult',checkSignIn,(req,res)=>{
    res.download("./files/duplicate.csv")
})
router.get('/deletedata',(req,res)=>{
    data.remove({},(err,result)=>{
        if(err) throw err;
        console.log('data deleted')
        res.write('data deleted');
        // res.write('response ending!!')
        res.end();
    })
    
})
router.get('/csvfile',checkSignIn, (req,res)=>{
    res.download('./filesformat/CSVFORMAT.csv')
})
router.get('/abmuploads',checkSignIn, (req,res)=>{
    metadata.find({name:"metadata"},(err,result)=>{
        if(err) throw err;
        // console.log(result)
        res.render('abmuploads.ejs',{user:req.session.user,data:result[0]})
        // res.render('abmuploads.ejs',{user:req.session.user,data:null})
    })
})
router.post('/abmuploads',checkSignIn, (req,res)=>{
    console.log(req.files);
    const file = req.files.file;
    const path = "./files/" + file.name;
    try {
        file.mv(path,(err)=>{
            if (err) {
                return res.status(500).send(err);
            }
            csv()
            .fromFile(path)
            .then((jsonObj)=>{
                console.log(jsonObj)
                if(jsonObj.length==0){
                   return res.send("file is empty!!")
                }
                // if(Object.keys(jsonObj[0]).length>1){
                //     return res.send("please upload only single")
                // }
                obj={};
                key=`${Object.keys(jsonObj[0])[0]}`
                key1=`${Object.keys(jsonObj[0])[1]}`
                console.log(key)
                console.log(key1)
                if(key=="domain"){
                    console.log("key is domain")
                    //perform operations on key
                    //leave operations for key1
                    var values=jsonObj.map(it=>{
                        return formatteddomain(Object.values(it)[0])
                    })
                    var values2=jsonObj.map(it=>{
                        return Object.values(it)[1]
                    })
                               
                    obj[key]=values;
                    obj[key1]=values2;
                }else{
                    //perform operations on key1
                    //leave operations for key
                    var values=jsonObj.map(it=>{
                        return Object.values(it)[0]
                    })
                    var values2=jsonObj.map(it=>{
                        return formatteddomain(Object.values(it)[1])
                    })
                               
                    obj[key]=values;
                    obj[key1]=values2;
                }
             
                console.log(obj)
                
                data.find({$or:[obj]},(err,result)  =>{
                    if(err) return res.send(err)
                    console.log(result.length);
    
                    let csv;
            const filePath = "./files/result.csv";
            const fields = require('../model/fields');
            try {
                const json2csvParser = new Parser({ fields });
                 csv = json2csvParser.parse(result);
                 
                 
            } catch (err) {
                return res.status(500).json({err});
            }
            fs.writeFile(filePath, csv, function (err) {
                if (err) {
                    return res.json(err).status(500);
                }
                else {
                    setTimeout(function () {
                        fs.unlink(filePath, function (err) { // delete this file after 30 seconds
                        if (err) {
                            console.error(err);
                        }
                        console.log('File has been Deleted');
                    });
                }, 30000);
                    res.download(filePath);
                    
                }
            })
                })
            }).then(()=>{
                setTimeout(() => {fs.unlink(path,(err)=>{
                    if(err) console.log(err)
                    console.log('file deleted')
                })}, 15000);
            });
    
        })
    } catch (err) {
        console.error(err)
        res.render('error.ejs',{user:req.session.user})
    }
    

})

function processabm(obj){
    abmobj={}
    Object.keys(obj[0]).forEach((item)=>{
        abmobj[item]=obj.map(it=>{return Object.values(it)[0]})
    })
    return abmobj
}

function processsuppressionquery(obj){
    let sobj={}
    Object.keys(obj[0]).forEach((item)=>{
        sobj[item]={$nin:obj.map(it=>{return Object.values(it)[0]})}
    })
    return sobj;
}
function getJsontoarray(path){
    csv()
    .fromFile(path)
    .then((jsonObj)=>{
        if(jsonObj.length==0){
            return res.send("file is empty");
        }
        abmobj=processabm(jsonObj)
        return abmobj
    })
}

function formatquery(element){
    let obj={};
    if(element.joblevel && element.joblevel!="" && element.joblevel!="Select--") (obj.joblevel=element.joblevel)
    if(element.jobfunction && element.jobfunction!="" && element.jobfunction!="Select--") (obj.jobfunction=element.jobfunction)
    if(element.jobtitle && element.jobtitle!="" && element.jobtitle!="Select--") (obj.jobtitle={$regex:getregex(element.jobtitle.split(';')), $options: "$i"})
    if(element.employeesizelower!="")  (obj.employeesizelower={$gte:element.employeesizelower})
    if(element.employeesizehigher!="")  (obj.employeesizehigher={$lte:element.employeesizehigher})
    if(element.industry!="" && element.industry!=undefined && element.industry!="Select--")  (obj.industry=element.industry)
    if(element.leadtype!="" && element.leadtype!=undefined && element.leadtype!="Select--")  (obj.leadtype=element.leadtype)
    if(element.revenuesizemapped!="" && element.revenuesizemapped!=undefined && element.revenuesizemapped!="Select--")  (obj.revenuesizemapped=element.revenuesizemapped)
    if(element.subindustry!="" && element.subindustry!="Select--")  (obj.subindustry={$regex:getregex(element.subindustry.split(';')), $options: "$i"})
    if(element.tags!="" && element.tags!="Select--" && element.tags!=undefined)  (obj.tags=element.tags)
    if(element.country!="" && element.country!="Select--")  (obj.country={$regex:getregex(element.country.split(';')), $options: "$i"})
    if(element.state!="" && element.state!="Select--")  (obj.state={$regex:getregex(element.state.split(';')), $options: "$i"})
    if(element.city!="" && element.city!="Select--")  (obj.city={$regex:getregex(element.city.split(';')), $options: "$i"})
    if(element.auditdate!="" && element.auditdate!="Select--")  (obj.auditdate={$gte:element.auditdate})
    if(element.leaddate!="" && element.leaddate!="Select--")  (obj.leaddate={$gte:element.leaddate})
    return obj;
}

function formatteddomain(element){
    if(element.startsWith("https://www")){
        return element.replace("https://www.","")
    }
    if(element.startsWith("https://")){
        return element.replace("https://","")
    }
    if(element.startsWith("http://")){
        return element.replace("http://","")
    }
    if(element.startsWith("www")){
        return element.replace("www.","")
    }
    return element;
}
function getvaluesinarray(obj){
    arr=obj.map(it=>{
        return Object.values(it)[0]
    })
    return arr;
}

function modifymetadata(element){
    //check weather the data exist
    // console.log(element)
    metadata.find({name:"metadata"},(err,result)=>{
        if(err){
            console.log(err);
        }else{
            console.log(result)
            if(result.length==0){
                obj={
                    name:"metadata",
                    companyname:[element.companyname],
                    jobtitle:[element.jobtitle],
                    jobfunction:[element.jobfunction],
                    joblevel:[element.joblevel],
                    city:[element.city],
                    state:[element.state],
                    zipcode:[element.zipcode],
                    country:[element.country],
                    industry:[element.industry],
                    industrytype:[element.industrytype]
                }
                var newmetadata = new metadata(obj)
                newmetadata.save();
            }else{
                console.log('item already there!')
                metadata.updateOne({name:'metadata'},
                { "$addToSet": { 
                    "companyname":{"$each":[element.companyname]} , 
                    "jobtitle":{"$each":[element.jobtitle]},
                    "jobfunction":{"$each":[element.jobfunction]},
                    "city":{"$each":[element.city]},
                    "state":{"$each":[element.state]},
                    "zipcode":{"$each":[element.zipcode]},
                    "country":{"$each":[element.country]},
                    "industry":{"$each":[element.industry]},
                    "industrytype":{"$each":[element.industrytype]},
                    "joblevel":{"$each":[element.joblevel]},
                    "qawebresearch":{"$each":[element.qawebresearch]}
             } },
                { "upsert": true },
                function(err,result){
                    if(err) throw err;
                    console.log(result)
                })
                // metadata.updateOne({name:'metadata'},{$addToSet:{
                //     companyname:{$each:[element.companyname]}
                // }})
            }
        }

    })
    
    //if data exist continue
    //if data dosent exist modify
}

function modifydatavar(object){
    // console.log(object)
    object.firstnamelower=object.firstname.toLowerCase();
    object.lastnamelower=object.lastname.toLowerCase();
    object.companynamelower=object.companyname.toLowerCase();
    object.emaillower=object.email.toLowerCase();
    // for (const k of Object.keys(object)) {
    //     object[k] = object[k].toLowerCase()
    // }
    // console.log(object)
    // object.tags=object.tags.toUpperCase();
    if((object.firstname=== "" || object.lastname=== "" || object.companyname=== "") && object.tags=== "")
        {
            object.tags="raw";
            return object;
        }
        else{
        // console.log(`from modifydatavar function ${object}`)
        return object;
    }
}


function uploadlog(content){
    fs.appendFile('./log/uploadlog/upload.log', content, err => {
        if (err) {
            console.error(err)
        }
        
    })
       
}

function getregex(values){
    let resultregex="";
    resultregex+="(";
    for(i=0;i<values.length;i++){
        resultregex+=values[i];
        if(i!=values.length-1){
            resultregex+="|";
        }
    }
    resultregex+=")"
    return resultregex
}

module.exports=router;