const express           =       require("express");
const app               =       express();
const dotenv            =       require('dotenv');
dotenv.config();
const db                =       require("./config/db");
const cookieParser      =       require('cookie-parser');
const bodyParser        =       require('body-parser');
var morgan              =       require('morgan')
const session           =       require('cookie-session');
const fileUpload        =       require('express-fileupload');
const userRoutes        =       require('./controller/usercontroller');
const dataRoutes        =       require('./controller/datacontroller');
const logRoutes         =       require('./controller/logcontroller');
var path                =       require('path');
var rfs                 =       require('rotating-file-stream');
// const bodyParser = require("body-parser");
// var urlencodedparser = bodyparser.urlencoded({extended:false})

const localtunnel       =       require('localtunnel');
(async () => {
    const tunnel = await localtunnel({ port: 3000 });
  
    // the assigned public url for your tunnel
    let url="192.168.80.60"
    tunnel.url;
      console.log("tunnel created")
    tunnel.on('close', () => {
        console.log('tunnel closed!!')
      // tunnels are closed
    });
})();


var accessLogStream = rfs.createStream('access.log', {
    interval: '1d', // rotate daily
    path: path.join(__dirname, 'log')
  })

app.use(morgan('combined', { stream: accessLogStream }))
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
// app.use(bodyParser.urlencoded({ extended: false }));
// app.use(bodyParser.json());
app.use(fileUpload({
    // createParentPath: true
}))
app.use(cookieParser());
app.use(session({secret:process.env.SECRET_KEY,
    resave: false,
    saveUninitialized: true,
    maxAge: 2*60* 60 * 1000 
}));
app.use(express.static(`${__dirname}/assets`));
app.use('/', userRoutes);
app.use('/', dataRoutes);
app.use('/', logRoutes);
app.listen(3000,()=>{
    console.log("server is up and running!!");
});