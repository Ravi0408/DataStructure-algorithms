//route: getdata 
// datacontroller
router.post('/getdata',checkSignIn,(req,res)=>{
    console.log(req.body)
    let obj=formatquery(req.body);
    console.log(obj)
    try {
        data.find({$and:[
            obj
        ]},(err,result)=>{
            if(err) throw err;
            console.log(result.length);
            res.json({count:result.length})
        })
    } catch (err) {
        console.error(err)
        res.render('error.ejs',{user:req.session.user})
    }
    
})

//route: downloaddata
//datacontroller

router.post('/downloaddata',checkSignIn,(req,res)=>{
    console.log(req.body)

    let obj=formatquery(req.body);
    try {
        data.find({$and:[
            obj
        ]},(err,result)=>{
            if(err) throw err;
            console.log(result.length);
            // console.log(result);
            // res.send(`${result.length}`)
            var downloadlog = new downloadlogger({
                totalcount:result.length,
                searchquery:JSON.stringify(obj),
                downloadedby:req.session.user.username,
                downloadedat:Date.now()
            })
            downloadlog.save();
    
            let csv;
            const filePath = "./files/result.csv";
            const fields = ['firstname','lastname','companyname','companywebsite','domain','jobtitle','joblevel','jobfunction','email','emailstatus','phonenumber','directnumber','address1','address2','city','state','province','zipcode','country','industry','subindustry','employeesize','employeesizelower','employeesizehigher','agentdisposition','wptitle','synopsis','contactlink','industrytypelink','employeesizelink','revenuesizelink','qcstatus','dqreason','qacomments','qawebreasearch','agentfeedback','leaddate','auditdate','leadtype','tags','source','technology'];
            try {
                const json2csvParser = new Parser({ fields });
                 csv = json2csvParser.parse(result);
                 
                 
            } catch (err) {
                return res.status(500).json({err});
            }
        
         fs.writeFile(filePath, csv, function (err) {
                if (err) {
                    return res.json(err).status(500);
                }
                else {
                    setTimeout(function () {
                        fs.unlink(filePath, function (err) { // delete this file after 30 seconds
                        if (err) {
                            console.error(err);
                        }
                        console.log('File has been Deleted');
                    });
        
                }, 30000);
                    res.download(filePath);
                }
            })
            // res.render('displaydata.ejs',{user:req.session.user,record:result})
            // res.json(result)
            // res.send(result)
        })
    } catch (err) {
        console.error(err)
        res.render('error.ejs',{user:req.session.user})
    }
    
    
})

// route: allfilters
// datacontroller
router.post('/allfilters',checkSignIn,async(req,res)=>{
    try {
        abmfile=req.files?.abmfile
        suppressionfile=req.files?.suppressionfile
        let obj=formatquery(req.body);
        if(Object.keys(obj).length === 0){
            return res.json({count:'please select filters'})
        }

        if(req.files?.abmfile==null && req.files?.suppressionfile==null ){   
            // no file exist
            console.log('no files')
            let obj=formatquery(req.body);
            let query={$and:[obj]};
            let result= await data.find(query).lean();
            console.log({count:result.length})
            return res.json({count:result.length})

        }else if(req.files?.suppressionfile==null){
            console.log('Abm file')
            const abmpath = "./files/" + abmfile.name;
            abmfile.mv(abmpath,(err)=>{
                if(err){
                    return res.status(500).send(err)
                }
                csv()
                .fromFile(abmpath)
                .then(async(jsonObj)=>{
                    if(jsonObj.length==0){
                        return res.send("file is empty");
                    }
                    abmobj=processabm(jsonObj);
                    let obj=formatquery(req.body);
                    let query={$and:[{$or:[obj]},{$or:[abmobj]}]};
                    let result= await data.find(query).lean();
                    console.log({count:result.length})
                    setTimeout(() => {fs.unlink(abmpath,(err)=>{
                        if(err) console.log(err)
                        console.log('abm file deleted')
                    })}, 150000);
                    return res.json({count:result.length})
                })
            })
            // abm exist and suppression dosent
        }else if(req.files?.abmfile==null){
            console.log('suppression file')
            const suppressionpath = "./files/" + suppressionfile.name;
            suppressionfile.mv(suppressionpath,(err)=>{
                if(err){
                    return res.status(500).send(err)
                }
                csv()
                .fromFile(suppressionpath)
                .then(async(jsonObj)=>{
                    if(jsonObj.length==0){
                        return res.send("file is empty");
                    }
                    sobj=processsuppressionquery(jsonObj);
                    let obj=formatquery(req.body);
                    let query={$and:[{$or:[obj]},sobj]};
                    console.log(query)
                    let result= await data.find(query).lean();
                    console.log({count:result.length})
                    setTimeout(() => {fs.unlink(suppressionpath,(err)=>{
                        if(err) console.log(err)
                        console.log('suppression file deleted')
                    })}, 150000);
                    return res.json({count:result.length})
                })
            })
            // abm dosent exist and suppression exist
        }else{
            console.log('both files')
            const abmpath = "./files/" + abmfile.name;
            abmfile.mv(abmpath,(err)=>{
                if(err){
                    return res.status(500).send(err)
                }
                csv()
                .fromFile(abmpath)
                .then(async(abmjsonObj)=>{
                    if(abmjsonObj.length==0){
                        return res.send("abm file is empty");
                    }
                    const suppressionpath = "./files/" + suppressionfile.name;
                    suppressionfile.mv(suppressionpath,(err)=>{
                        if(err){
                            return res.status(500).send(err)
                        }
                        csv()
                        .fromFile(suppressionpath)
                        .then(async(jsonObj)=>{
                            if(jsonObj.length==0){
                                return res.send("suppression file is empty");
                            }
                            abmobj=processabm(abmjsonObj);
                            suppressionobj=processabm(jsonObj);
                            let obj=formatquery(req.body);
                            let query={$and:[{$or:[obj]},{$or:[abmobj]}]};
                            console.log(query)
                            let result= await data.find(query).lean();
                            console.log({count:result.length})
                            setTimeout(() => {fs.unlink(suppressionpath,(err)=>{
                                if(err) console.log(err)
                                console.log('suppression file deleted')
                            })}, 150000);
                            setTimeout(() => {fs.unlink(abmpath,(err)=>{
                                if(err) console.log(err)
                                console.log('abm file deleted')
                            })}, 150000);
                            return res.json({count:result.length})
                        })
                    })
                    abmobj=processabm(jsonObj);
                    let obj=formatquery(req.body);
                    let query={$and:[{$or:[obj]},{$or:[abmobj]}]};
                    let result= await data.find(query).lean();
                    console.log({count:result.length})
                    
                    
                    return res.json({count:result.length})
                })
            })
            //both file exist
        }

       
    } catch (err) {
        console.error(err)
        res.render('error.ejs',{user:req.session.user})
    }
})