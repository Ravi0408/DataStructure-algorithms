class Process{
    constructor(processname){
        this.processname=processname
        this.processcount=0
        this.totalCount=0
    }
    setTotalCount(number){
        this.totalCount=number;
    }
    getTotalCount(){
        return this.totalCount;
    }
    getProcessName(){
        return this.processname;
    }
    setProcessCount(processcount){
        this.processcount=processcount
    }
    getProcesscount(){
        return this.processcount
    }
}


const p=new Process("myprocess")
const t=new Process("45646")
p.setTotalCount(15000);
console.log(p.getProcessName())
console.log(p)
console.log(p.getTotalCount())
p.setProcessCount(87)
console.log(p)
p.destroy()
console.log(p)
