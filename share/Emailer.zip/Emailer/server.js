var express = require('express');
var app = express();
var counter = 0;
app.get('/', function (req, res) {
   res.send(
    '<form action="/server" method="POST">' +
    '  <input type="submit" name="server" value="Run Script" />' +
    '</form>');
});
app.get('/counter', function (req, res) {
    counter++;
  res.end("Counter = " + counter);
});
app.post('/server', function (req, res) {
  var fork = require('child_process').fork;
  var child = fork('./test');
  counter ++;
  console.log(counter)
  child.on("close", function () { counter --; });
  res.send('Test Started....');
});
var server = app.listen(8081, function () {
   var host = server.address().address
   var port = server.address().port
   console.log("Example app listening at")})