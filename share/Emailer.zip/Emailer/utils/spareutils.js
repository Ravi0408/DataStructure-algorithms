
//smtp
// router.post('/sendemail',(req,res)=>{
//   smtpProtocol = nodemailer.createTransport({
//     host: "send.smtp.com", 
//     auth: {
//         user: "jack.smith@martechpapers.online",
//         pass: "Apple@2022$$$!!!"
//     }
//   });
//   var mailoption = {
//     from: "jack.smith@martechpapers.online",
//     to: "acceligize@gmail.com",
//     subject: "smtp test ",
//     html: 'check check mic test mic test'
//   }


//   smtpProtocol.sendMail(mailoption, function(err, response){
//     if(err) {
//       smtpProtocol.close();
//       return console.log(err);
//     } 
//     console.log('Message Sent' + response);
//     res.send(response)
//     smtpProtocol.close();
//   });
// })

// Sparkpost
// router.post('/sendemail',(req,res)=>{
//   console.log(req.body);
//   const client = new SparkPost(process.env.Sparkpost);

//   client.transmissions.send({
//     options: {
//       // sandbox: true
//     },
//     content: {
//       from: 'jack@itbusinessinfo.com',
//       subject: req.body.subject,
//       html:req.body.text
//     },
//     recipients: [
//       {address: 'jack.smith@martechpapers.online'}
//     ]
//   })
//   .then(data => {
//     console.log('Woohoo! You just sent your first mailing!');
//     console.log(data);
//   })
//   .catch(err => {
//     console.log('Whoops! Something went wrong');
//     console.log(err);
//   })
//   .then(res.send("done!"));
// })


// sendgrid
// router.post('/sendemail',(req,res)=>{
//   console.log(req.body);
//   sgMail.setApiKey(process.env.APIkey);
//   List.find({_id:req.body.list},(err,result)=>{
//     if(err) return res.send(err)
//     console.log(result[0].list);
//     const msg = {
//       to: result[0].list, // replace these with your email addresses
//       from: 'newsletters@businessinfopro.com',
//       subject: req.body.subject,
//       // text: req.body.text,
//       html: req.body.text,
//       // html: '<p>Fresh donuts are out of the oven. Get them while they’re <em>hot!</em></p>',
//     };
//     sgMail.sendMultiple(msg).then(() => {
//       console.log('emails sent successfully!');
//       res.send("done!")
//     }).catch(error => {
//       console.log(error);
//       console.log(error.response.body.errors);
//     });
//   })
// })
