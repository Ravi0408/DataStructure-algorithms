class Node {
    constructor(element)
    {
        this.element = element;
        this.next = null
    }
}
class ProcessList {
    constructor()
    {
        this.head = null;
        this.size = 0;
    }
    add(element)
    {
        var node = new Node(element);
        var current;
        if (this.head == null)
            this.head = node;
        else {
            current = this.head;
            while (current.next) {
                current = current.next;
            }
            current.next = node;
        }
        this.size++;
    }
    removeElement(name)
    {
        var current = this.head;
        var prev = null;
        while (current != null) {
            if (current.element.processname === name) {
                if (prev == null) {
                    this.head = current.next;
                } else {
                    prev.next = current.next;
                }
                this.size--;
                return current.element;
            }
            prev = current;
            current = current.next;
        }
        return -1;
    }
    updateprocess(name,count){
        var current = this.head;
        // for(let i=0;i<this.size_of_list();i++){
        //     if (current.element.processname == name) {
        //         console.log(`processname${current.element} name:${name}`)
        //         current.element.processcount=count;
        //         return current.element;
        //     }
        //     current = current.next;
        // }
        while (current != null) {
            if (current.element.processname == name) {
                console.log(`processname${current.element} name:${name}`)
                current.element.processcount=count;
                return current.element;
            }
            current = current.next;
        }
    }
    isEmpty()
    {
        return this.size == 0;
    }
    size_of_list()
    {
        return this.size;
    }
    printList()
    {
        if(this.size_of_list()==0){
            return [];
        }
        var curr = this.head;
        var str = [];
        while (curr) {
            str.push(curr.element);
            curr = curr.next;
        }
        console.log(str);
        return str;
    }

}

module.exports=ProcessList