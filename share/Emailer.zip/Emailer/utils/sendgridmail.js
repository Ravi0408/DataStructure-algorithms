const sgMail = require('@sendgrid/mail');
sgMail.setApiKey(process.env.APIkey);

const msg = {
  to: ['example1@mail.com', 'example2@mail.com'], // replace these with your email addresses
  from: 'Sadie Miller <sadie@thebigdonut.party>',
  subject: '🍩 Donuts, at the big donut 🍩',
  text: 'Fresh donuts are out of the oven. Get them while they’re hot!',
  html: '<p>Fresh donuts are out of the oven. Get them while they’re <em>hot!</em></p>',
};

sgMail.sendMultiple(msg).then(() => {
  console.log('emails sent successfully!');
}).catch(error => {
  console.log(error);
});