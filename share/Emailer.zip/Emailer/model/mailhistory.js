const mongoose =require('mongoose');

const historySchema= new mongoose.Schema({
    tool:{
        type:String
    },
    subject:{
        type:String
    },
    listname:{
        type:String
    },
    mailcount:{
        type:Number
    },
    email:{
        type:String
    },
    completedat:{
        type:Number
    },
    executive:{
        type:String
    }
});
module.exports =mongoose.model('History',historySchema);