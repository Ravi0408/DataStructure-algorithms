const mongoose =require('mongoose');

const listSchema= new mongoose.Schema({
    listname:{
        type:String,
        unique:true
    },
    list:{
        type:[{
            name:String,
            email:String
        }]
    },
    uploadedby:{
        type:String
    },
    uploadedat:{
        type:Number
    }

});
module.exports =mongoose.model('list',listSchema);