const mongoose =require('mongoose');

const smtpSchema= new mongoose.Schema({
    smtpname:{
        type:String,
        unique:true
    },
    tool:{
        type:String
    },
    senderemail:{
        type:String
    },
    sendername:{
        type:String
    },
    apikey:{
        type:String
    },
    host:{
        type:String
    },
    user:{
        type:String
    },
    pass:{
        type:String
    }
});

module.exports =mongoose.model('smtp',smtpSchema);