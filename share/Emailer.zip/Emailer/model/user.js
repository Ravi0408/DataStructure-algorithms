const mongoose =require('mongoose');

const userSchema= new mongoose.Schema({
    username:{
        type:String,
    },
    employeeID:{
        type:String,
    },
    department:{
        type:String,
        enum:['MIS','QA','Sales','HOOP','Data','Email','SuperAdmin'],
        default:'Data'
    },
    password:{
        type:String,
    },
    role:{
        type:String,
        enum:['Admin','Manager','Basic'],
        default:'Basic'
    },
    email:{
        type:String,
    },
});
module.exports =mongoose.model('User',userSchema);