const router=       require('express').Router();
const List=         require('../model/list');
var nodemailer = require('nodemailer');
const sgMail = require('@sendgrid/mail');
const fs= require("fs")
var dotenv = require("dotenv")
dotenv.config();
const csv=          require('csvtojson');
const {checkSignIn,checkSignOut,isManager,isadmin}=           require('./auths');


router.get('/addlist',checkSignIn,(req,res)=>{
    res.render('addlist.ejs',
    {user:req.session.user}
    );
  });

router.post('/addlist',checkSignIn,async (req,res)=>{
console.log(req)
console.log(req.files)
// console.log(req.session.user.username);
const file = req.files.file;
const path = "./files/" + file.name;
file.mv(path, (err) => {
    if (err) {
        return res.status(500).send(err);
    }
    csv()
    .fromFile(path)
    .then(async (jsonObj)=>{
        console.log(jsonObj)
        // var values=jsonObj.map(it=>{
        // return it.emails;
        // })
        // console.log(values);
        var list =new List({
            listname:file.name,
            list:jsonObj,
            uploadedby:req.session.user.username,
            uploadedat:Date.now()
        })
        try{
            const savedlist= await list.save();
            res.send(savedlist);
        }catch(err){
            console.log(err);
            res.send("0");
            // res.status(400).send("Error occured");
        }
        })
    .then(setTimeout(() => {fs.unlink(path,(err)=>{
        if(err) console.log(err)
        console.log('file deleted')
    })}, 150000))
})

})

router.get('/viewlist',checkSignIn,(req,res)=>{
    List.find({},(err,result)=>{
        if(err) return res.send(err)
        res.render("emaillist.ejs",{records:result,user:req.session.user})
    })
})
module.exports=router;