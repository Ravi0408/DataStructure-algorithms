const router=       require('express').Router();
const List=         require('../model/list');
const Smtp=         require('../model/smtp');
var nodemailer = require('nodemailer');
const sgMail = require('@sendgrid/mail');
var dotenv = require("dotenv")
dotenv.config();
const csv=          require('csvtojson');
const smtp = require('../model/smtp');
const {checkSignIn,checkSignOut,isManager,isadmin}=           require('./auths');


router.get('/addsmtp',checkSignIn,(req,res)=>{
    res.render('addsmtp.ejs',
    {user:req.session.user}
    );
});

router.post('/addsmtp',checkSignIn, async (req,res)=>{
    console.log(req.body)
    var smtp = new Smtp(req.body);
    try {
        const savedsmtp= await smtp.save();
        res.send("saved to database")
    } catch (error) {
        console.log(err);
        res.status(400).send("Error occured");
    }
})
module.exports=router;