const router=       require('express').Router();
const User=         require('../model/user');
const fs=           require('fs');
const bcrypt=       require('bcryptjs');
const History=         require('../model/mailhistory');
const {checkSignIn,checkSignOut,isManager,isadmin}=           require('./auths');
router.get('/mailhistory',checkSignIn,async(req,res)=>{
    result =await History.find({}).sort({completedat:1});
    res.render("mailhistory.ejs",{data:result,user:req.session.user})
    // History.find({},(err,result)=>{
    //     if(err) return res.send(err)
    //     console.log(result)
    //     res.render("mailhistory.ejs",{data:result,user:req.session.user})
    // })
})
module.exports=router;