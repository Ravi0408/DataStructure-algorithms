const router=       require('express').Router();
const List=         require('../model/list');
const Smtp=         require('../model/smtp');
const User=         require('../model/user');
const History=         require('../model/mailhistory');
var nodemailer =require('nodemailer');
const SparkPost = require('sparkpost');
const sgMail = require('@sendgrid/mail');
var dotenv = require("dotenv")
dotenv.config();
const csv=          require('csvtojson')
const async = require('async');
const {checkSignIn,checkSignOut,isManager,isadmin}=require('./auths');
const ProcessList= require("../utils/processlist");
const express           =       require("express");
const { db } = require('../model/list');
const app               =       express();
const http              =       require('http').Server(app);
const io                =       require('socket.io')(http);
const process=new ProcessList()
router.get('/',checkSignIn,async (req,res)=>{
  listcount= await (await List.find({})).length;
  smtp=await (await Smtp.find({})).length
  usercount=await (await User.find({})).length
  mailsent=await History.aggregate([
    // {"$match":{"completedat":{$lte:Date.now()}}},
    {"$group":{"_id":null,"totalmailcount":{"$sum":"$mailcount"}}}
  ])
  res.render('index.ejs',
      {
        user:req.session.user,
        smtpcount:smtp,
        listcount:listcount,
        mailcount:mailsent[0].totalmailcount,
        usercount:usercount
      }
      );
});

router.get('/sendemail',checkSignIn,(req,res)=>{
  List.find({},(err,result)=>{
    if(err){
      return console.log(err)
    }
    else{
      Smtp.find({},(err,smtpdata)=>{
        if(err) return res.send(err)
        res.render('sendemail.ejs',
          {
            data:result,
            smtpdata:smtpdata,
            user:req.session.user
          }
        );
      })
    }
  })
});
router.get('/getprocesses',(req,res)=>{
  thisobject=process.printList();
  // console.log(thisobject)
  // parsed=JSON.parse(thisobject)
  res.send(thisobject)
})

// router.get('/results',(req,res)=>{
//   let fs = require('fs'),

// reader = fs.createReadStream('./utils/nodemailer.js', {
// 	flag: 'a+',
// 	encoding: 'UTF-8',
// 	// start: 5,
// 	// end: 64,
// 	// highWaterMark: 16
// });

// // Read and display the file data on console
// data="";
// reader.on('data', function (chunk) {
// 	console.log(chunk);
//   data=data+chunk
//   // res.send(chunk);
// });
// res.send(data)
// })
// router.get('/sendmails',(req,res)=>{
//   console.log(req.query);
//   for(i=0;i<100;i++){
//     res.write("okay")
//   }
// })


router.post('/sendmails',checkSignIn,(req,res)=>{
  console.log(req.body)
    Smtp.find({_id:req.body.tool},async (err,smtptooldata)=>{
      if(err) return res.write(err)
      // console.log(smtptooldata)
      // console.log(tool)
      if(smtptooldata[0].tool=='sendgrid'){
        sgMail.setApiKey(smtptooldata[0].apikey);
          List.find({_id:req.body.list},(err,result)=>{
            if(err) return res.write(err)
            
            // var io = req.app.get('socketio');
            // let mysocket;
            // io.on("connection", socket => {
            //   // socket.join(req.session.user);
            //   mysocket=socket
            // });
            // res.render('result.ejs',{user:req.session.user});
            // res.write("process started")
              async.eachOfSeries(result[0].list, function(dataVar, key, callback) {
                // write saparate function
              const msg = {
                  to: dataVar.email,
                  from: smtptooldata[0].senderemail, 
                  subject: req.body.subject,
                  html: processhtml(req.body.text,dataVar.name),
              };
              // console.log(msg)
              sgMail
              .send(msg)
              .then((response) => {
                console.log(response[0].statusCode)
                console.log(response[0].headers)
                // processcount++;
                // process.updateprocess(thisprocessname,processcount)
                res.write(`\n${dataVar.name}:ok`)
                callback()
              })
              .catch((error) => {
                console.error(error)
                callback()
              })
              // setTimeout(() => {
              //    console.log(`\n${dataVar.name}:ok`)
              //   // io.to(mysocket.id).emit("message",`\n${dataVar.name}:ok`);
              //   callback()
              // }, 1000)
            },
            async function(err) {
              if (err) console.error(err.message);
              // configs is now a map of JSON data
              // process.removeElement(thisprocessname)
              console.log("All done")
              //mark history
              const history = new History({
                tool:smtptooldata[0].tool,
                subject:req.body.subject,
                listname:result[0].listname,
                mailcount:result[0].list.length,
                email:smtptooldata[0].senderemail,
                completedat:Date.now(),
                executive:req.session.user.username
            });
            try{
                const savedHistory= await history.save()
            }catch(err){
                console.log(err);
                res.status(400).send("Error occured");
            }
              // io.to(mysocket.id).emit(`\ndone dana done`);
              return res.send("ok")
              res.end()
            });
          
          })
      }else if(smtptooldata[0].tool=='sparkpost'){
          List.find({_id:req.body.list},(err,result)=>{
            if(err) return res.send(err)
            // console.log(result);
            // console.log("sparkpost");
            const client = new SparkPost(smtptooldata[0].apikey);
            async.eachOfSeries(result[0].list, function(dataVar, key, callback) {
              client.transmissions.send({
                    options: {
                        // sandbox: true
                      },
              content: {
                  from: smtptooldata[0].senderemail,
                  subject: req.body.subject,
                  html:processhtml(req.body.text,dataVar.name),
                },
                recipients:[{address:dataVar.email}]
              })
              .then(data => {
                console.log('mail sent');
                console.log(data);
                callback()
              })
              .catch(err => {
                console.log('Whoops! Something went wrong');
                console.log(err);
                callback()
              });    
            },
            async function(err) {
              if (err) console.error(err.message);
              // configs is now a map of JSON data
              console.log("All done")
              const history = new History({
                tool:smtptooldata[0].tool,
                subject:req.body.subject,
                listname:result[0].listname,
                mailcount:result[0].list.length,
                email:smtptooldata[0].senderemail,
                completedat:Date.now(),
                executive:req.session.user.username
            });
            try{
                const savedHistory= await history.save()
            }catch(err){
                console.log(err);
                res.status(400).send("Error occured");
            }
              return res.send("ok")
              });
            })
      }else{
        List.find({_id:req.body.list},(err,result)=>{
          if(err) return res.send(err)
          // console.log(result);
          // console.log("smtp");
              smtpProtocol = nodemailer.createTransport({
                host: smtptooldata[0].host, 
                auth: {
                    user: smtptooldata[0].user,
                    pass: smtptooldata[0].pass
                }
              });
          async.eachOfSeries(result[0].list, function(dataVar, key, callback) {
            const mailoption = {
                to: dataVar.email,
                from: smtptooldata[0].senderemail,
                subject: req.body.subject,
                html: processhtml(req.body.text,dataVar.name),
            };
                smtpProtocol.sendMail(mailoption, function(err, response){
                if(err) {
                  smtpProtocol.close();
                  return callback()
                  // return res.send(err);
                } 
                console.log('Message Sent' + response);
                smtpProtocol.close();
                callback()
                // res.send(response)
              });
              // console.log(msg)
          },
          async function(err) {
                if (err) console.error(err.message);
                // configs is now a map of JSON data
                console.log("All done")
                const history = new History({
                  tool:smtptooldata[0].tool,
                  subject:req.body.subject,
                  listname:result[0].listname,
                  mailcount:result[0].list.length,
                  email:smtptooldata[0].senderemail,
                  completedat:Date.now(),
                  executive:req.session.user.username
              });
              try{
                  const savedHistory= await history.save()
              }catch(err){
                  console.log(err);
                  res.status(400).send("Error occured");
              }
                return res.send("ok")
            });
        })
      }
    })

})


function processhtml(text,name){
  const regex = /{{firstname}}/ig
    processedtext=text.replace(regex,name)
  return processedtext;
}
module.exports=router;