const express           =       require("express");
const app               =       express();
const dotenv            =       require('dotenv');
dotenv.config();
const db                =       require("./config/db");
const cookieParser      =       require('cookie-parser');
const bodyParser        =       require('body-parser');
var morgan              =       require('morgan')
const session           =       require('cookie-session');
const fileUpload        =       require('express-fileupload');
const sendRoutes        =       require('./controller/controller');
const userRoutes        =       require('./controller/usercontroller');
const listRoutes        =       require('./controller/listcontroller');
const smtpRoutes        =       require('./controller/smtpcontroller');
const historyRoutes     =       require('./controller/historycontroller');
var path                =       require('path');
var rfs                 =       require('rotating-file-stream');
const http              =       require('http').Server(app);
const io                =       require('socket.io')(http);

const localtunnel       =       require('localtunnel');
(async () => {
    const tunnel = await localtunnel({ port: 8000 });
    let url="192.168.80.121"
    tunnel.url;
      console.log("tunnel created")
    tunnel.on('close', () => {
      console.log('tunnel closed!!')
    });
})();

var accessLogStream = rfs.createStream('access.log', {
    interval: '1d',
    path: path.join(__dirname, 'log')
  })
  
  app.use(morgan('combined', { stream: accessLogStream }))
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  app.use(cookieParser());                     
  app.use(session({
    secret:process.env.SECRET_KEY,
    resave: false,
    saveUninitialized: true,
    maxAge: 10*60* 60 * 1000 
}));
app.use(fileUpload({
    // createParentPath: true
  }))
app.set('socketio', io);
// io.on('connection', function(socket) {
//   console.log('A user connected');

//   socket.on('disconnect', function () {
//       console.log('A user disconnected');
//   });
// })

app.use(express.static(`${__dirname}/assets`));
app.use('/', sendRoutes);
app.use('/', userRoutes);
app.use('/', listRoutes);
app.use('/', smtpRoutes);
app.use('/', historyRoutes);

http.listen(8000,()=>{
  console.log("server is up and running!!");
})

// app.listen(3000,()=>{
//     console.log("server is up and running!!");
// });